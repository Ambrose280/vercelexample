from tortoise import Tortoise
async def connectToDatabase():
    await Tortoise.init(
        db_url='sqlite://db_bot.sqlite3',
        modules={'models': ['models']}
    )