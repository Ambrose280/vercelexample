from pydantic import BaseModel

class UpdateGamePts(BaseModel):
    gamepts: int