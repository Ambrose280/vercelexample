from aiogram import types
from aiogram.dispatcher.middlewares import BaseMiddleware
from aiogram.types import ChatMemberStatus
from aiogram.dispatcher.handler import CancelHandler

CHANNEL_USERNAME = 'ifioktestchannel'

class ChannelCheckMiddleware(BaseMiddleware):
    def __init__(self, channel_username):
        self.channel_username = channel_username
        super(ChannelCheckMiddleware, self).__init__()

    async def on_process_message(self, message: types.Message, data: dict):
        bot = message.bot
        user_id = message.from_user.id
        
        member = await bot.get_chat_member(chat_id=f"@{self.channel_username}", user_id=user_id)
        
        if member.status not in [ChatMemberStatus.MEMBER, ChatMemberStatus.ADMINISTRATOR, ChatMemberStatus.CREATOR]:
            await message.answer("You must join our channel first! Please join the channel and then restart the bot.")
            await message.answer(f"Join our channel: https://t.me/{self.channel_username}")
            raise CancelHandler()